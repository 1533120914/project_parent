create definer = root@localhost view dept_emp_count as
select count(0)                                                                         AS `count`,
       (select `d`.`name` from `db_memsys`.`dept` `d` where (`d`.`id` = `a`.`dept_id`)) AS `dept_name`
from `db_memsys`.`account` `a`
where (`a`.`identity` = 2)
group by `a`.`dept_id`;

