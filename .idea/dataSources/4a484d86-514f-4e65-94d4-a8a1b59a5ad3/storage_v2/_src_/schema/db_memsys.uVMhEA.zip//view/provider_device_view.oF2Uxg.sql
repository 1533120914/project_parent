create view provider_device_view as
select `d`.`id`            AS `device_id`,
       `d`.`name`          AS `device_name`,
       `p`.`id`            AS `provider_id`,
       `p`.`provider_name` AS `provider_name`,
       `r`.`price`         AS `price`
from ((`db_memsys`.`provider` `p` join `db_memsys`.`provider_device_relation` `r` on ((`p`.`id` = `r`.`provider_id`)))
         join `db_memsys`.`device_type` `d` on ((`d`.`id` = `r`.`device_id`)));

-- comment on column provider_device_view.device_id not supported: 设备类型id

-- comment on column provider_device_view.device_name not supported: 设备类型名称

-- comment on column provider_device_view.provider_id not supported: 供应商id

-- comment on column provider_device_view.provider_name not supported: 供应商名称

