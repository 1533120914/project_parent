create definer = root@localhost view dept_view as
select `a`.`id`                                                                                        AS `employee_id`,
       `a`.`username`                                                                                  AS `username`,
       `d`.`id`                                                                                        AS `dept_id`,
       `d`.`name`                                                                                      AS `dept_name`,
       (select count(0) from `db_memsys`.`account` where (`db_memsys`.`account`.`dept_id` = `d`.`id`)) AS `count`
from (`db_memsys`.`account` `a`
         join `db_memsys`.`dept` `d` on ((`a`.`id` = `d`.`header_id`)));

-- comment on column dept_view.employee_id not supported: 主键id

-- comment on column dept_view.username not supported: 用户名

